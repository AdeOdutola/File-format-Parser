namespace StrapzApp {
    class Table {
        // 2D String array of all the literals
        public String[][] Words { get; set; }

        // Types of each columns - String or Number
        public String[] Types { get; set; }
        

        public Table(String[][] words, String[] types) {
            Words = words;
            Types = types;
        }

        // Prints the type of each column and the 2D array
        public void Print() {
            Console.Write("Types: ");

            for (int i = 0; i < Types.Length; ++i) {
                Console.Write(Types[i] + " ");
            }
            
            Console.WriteLine();

            for (int i = 0; i < Words.Length; ++i) {
                for (int j = 0; j < Words[i].Length; ++j) {
                    Console.Write(Words[i][j] + " ");
                }

                Console.WriteLine();
            }
        }
    }
}