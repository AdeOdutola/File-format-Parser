namespace StrapzApp {
    class CsvParser {
        // convert intermediate table format to CSV format
        public static string Create(Table table) {
            String[][] words = table.Words; 
            String csv = "";

            for (int i = 0; i < words.Length; ++i) {
                for (int j = 0; j < words[i].Length; ++j) {
                    if (words[i][j].Equals("-")) {
                        csv += "\"-\"";
                    }

                    else {
                        if (i == 0 || table.Types[j] == "String") {
                            csv += "\"" + words[i][j] + "\"";
                        }

                        else {
                            csv += words[i][j];  
                        }
                    }

                    if (j != words[i].Length - 1) {
                        csv += ",";
                    }
                }

                if (i != words.Length - 1) {
                    csv += "\n";
                }
            }            

            return csv;
        }

        // convert Csv format to intermediate Table format
        public static Table Parse(string text) {
            // split the csv table into lines
            string[] lines = text.Split('\n');

            // split each lines into words with comma as delimiter
            string[][] words = lines.Select(x => x.Split(',')).ToArray();

            string[] types = new string[words[0].Length];

            // determine type of each column
            for (int i = 0; i < words[0].Length; ++i) {
                for (int j = 1; j < words.Length; ++j) {
                    if (words[j][i].Equals("-")) {
                        continue;
                    }

                    if (words[j][i].StartsWith("\"")) {
                        types[i] = "String";
                    }

                    else {
                        types[i] = "Number";
                    }
                }
            }

            // preprocess to remove trailing / leading white spaces, newlines etc
            for (int i = 0; i < words.Length; ++i) {
                for (int j = 0; j < words[i].Length; ++j) {
                    words[i][j] = words[i][j].Replace("\"", "");
                    
                    if (j == words[i].Length - 1 && i != words.Length - 1) {
                        words[i][j] = words[i][j].Remove(words[i][j].Length - 1); 
                    }

                    words[i][j] = words[i][j].Trim();
                }
            }
            
            return new Table(words, types);
        }
    }
}