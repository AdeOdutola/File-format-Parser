using System.Collections.Generic;
using System.Text.RegularExpressions;

namespace StrapzApp {
    class HtmlParser {
        // convert intermediate table format to HTML format
        public static string Create(Table table) {
            String[][] words = table.Words; 

            String html = "";

            html += "<table>\n";

            for (int i = 0; i < words.Length; ++i) {
                html += "\t<tr>\n";

                String tag = (i == 0) ? "th" : "td";

                for (int j = 0; j < words[i].Length; ++j) {
                    String add = (i > 0 && table.Types[j] != "String") ? " align=\"\"right\"\"" : "";

                    html += "\t\t" + "<" + tag + add + ">" + words[i][j] + "</" + tag + ">\n";
                } 

                html += "\t</tr>\n";
            }

            html += "</table>";

            return html;
        } 

        // convert HTML format to intermediate Table format
        public static Table Parse(String text) {
            String[] lines = text.Split('\n');

            int rows = 0, columns = 0;

            // count number of rows and columns
            for (int i = 0; i < lines.Length; ++i) {
                String line = lines[i];

                if (line.Contains("<tr")) rows++;
                if (line.Contains("<th")) columns++;
                if (line.Contains("<td")) columns++;
            }

            columns /= rows;

            String[][] words = new String[rows][];

            for (int i = 0; i < rows; ++i)
                words[i] = new String[columns];

            String[] types = new String[columns];

            for (int i = 0; i < columns; ++i)
                types[i] = "String";

            int current = 0;

            for (int i = 0; i < lines.Length; ++i) {
                String line = lines[i];

                // get the data between first > and the < after that 
                // that data is stored into 'inner'
                int l = 0;
                while (l < line.Length && line[l] != '>') ++l;
                ++l;

                int r = l;
                while (r < line.Length && line[r] != '<') ++r;
                r--;

                if (l <= r) {
                    String inner = line.Substring(l, r - l + 1);

                    if (inner[0] == '\n' || inner[0] == '\t' || (int)inner[0] == 13) {
                        continue;
                    }

                    words[current / columns][current % columns] = inner;
                    current++;       
                }
            }            

            return new Table(words, types);   
        }
    }
}