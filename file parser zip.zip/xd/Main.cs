﻿using System; 

namespace StrapzApp {
    class Strapz {
        static void Main(string[] args) {
            // input and output file names
            String inFile = "", outFile = "";
            bool verbose = false;
            Console.WriteLine("To help running parser type 'dotnet run v h");

            // set the flow based on arguments
            for (int i = 0; i < args.Length; ++i) {
                if (args[i].Equals("-i")) {
                    inFile = args[i+1];
                }

                else if (args[i].Equals("-o")) {
                    outFile = args[i+1];
                }

                else if (args[i].Equals("v")) {
                    verbose = true;
                }
                else if (args[i].Equals("h")) {
                    Console.WriteLine("To run app type 'dotnet run -i input.format and -o output.format' ");
                    return;

                }
                else if (args[i].Equals("i")) {
                    Console.Write("inputs csv html and json files and outputs json html and csv \nfile being parsed will be outputted in the editor");
                    return;

                }
                else if (args[i].Equals("l")) {
                    Console.Write(".html");
                    Console.Write(".csv");
                    Console.Write(".json");
                    return;

                }

            }

            // read input
            string input = System.IO.File.ReadAllText(inFile);
            string output = "";
            Table table = null;
            
            // convert the input file contents into the intermediate Table format (with 2d string array)
            if (inFile.EndsWith(".csv")) {
                table = CsvParser.Parse(input);
            }

            else if (inFile.EndsWith(".html")) {
                table = HtmlParser.Parse(input);
            }

            else if (inFile.EndsWith(".json")) {
                table = JsonParser.Parse(input);
            }

            // print the table if verbose mode is set
            if (verbose) {
                table.Print();
            }

            // convert the content in intermediate table format into the output format
            if (outFile.EndsWith(".csv")) {
                output = CsvParser.Create(table);
            }

            else if (outFile.EndsWith(".html")) {
                output = HtmlParser.Create(table);
            }

            else if (outFile.EndsWith(".json")) {
                output = JsonParser.Create(table);
            }

            // write the output into the file
            System.IO.File.WriteAllText(outFile, output);
        }
    }
}