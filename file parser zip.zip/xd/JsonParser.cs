namespace StrapzApp {
    class JsonParser {
        // convert intermediate table format to JSON format
        public static string Create(Table table) {
            String[][] words = table.Words; 

            String json = "";

            json += "[\n";

            for (int i = 1; i < words.Length; ++i) {
                json += "\t{\n";
                
                for (int j = 0; j < words[i].Length; ++j) {
                    json += "\t\t\"" + words[0][j] + "\": ";

                    // if current column is String, then append a "
                    if (table.Types[j].Equals("String") || words[i][j].Equals("-")) {
                        json += "\"";
                    }

                    if (words[i][j].Equals("-")) {
                        json += "-";
                    }

                    else {   
                        json += words[i][j];
                    }

                    if (table.Types[j].Equals("String") || words[i][j].Equals("-")) {
                        json += "\"";
                    }

                    if (j != words[i].Length - 1) {
                        json += ",";
                    }

                    json += "\n";
                }

                json += "\t}";

                if (i != words.Length - 1) {
                    json += ",";
                }

                json += "\n";
            }

            json += "]";

            return json;
        } 


        // convert JSON format to intermediate Table format
        public static Table Parse(String text) {
            // Dictionary to keep track of respective column numbers of keys (in case keys dont always come in same order)
            Dictionary<string, int> columnOf = new Dictionary<string, int>();

            // not really a proper way to count rows and columns
            // but we can assume rows as number of { and columns as number of : divided by number of rows
            int rows = text.Count(x => x == '{');
            int columns = text.Count(x => x == ':') / rows;

            String[][] words = new String[rows+1][];
            String[] types = new String[columns];

            for (int i = 0; i <= rows; ++i)
                words[i] = new String[columns];

            int curColumn = 0;

            for (int i = 0; i < text.Length; ++i) {
                String key = "";
                String value = "";

                // every key value pair is of format
                // "key": "value" or "key" value
                // so when we encounter a ", we can get the key and values with a simple state machine
                if (text[i] == '\"') {
                    i++;

                    while (i < text.Length && text[i] != '\"') {
                        key += text[i];
                        i++;
                    }

                    i++;

                    while (i < text.Length && (text[i] == ' ' || text[i] == ':')) {
                        i++;
                    }

                    bool isString = false;

                    if (text[i] == '\"') {
                        i++;
                        isString = true;
                    }

                    while (i < text.Length && text[i] != ',' && text[i] != '\n') {
                        if (text[i] == '\"') {
                            i++;
                            continue;
                        }

                        value += text[i];
                        i++;
                    }

                    i++;

                    int j = -1;
                    if (!columnOf.TryGetValue(key, out j)) {
                        j = curColumn;
                        columnOf[key] = curColumn;
                        words[0][j] = key.Trim();                        
                    }

                    int r = curColumn / columns;

                    words[r+1][j] = value.Trim();

                    if (isString) {
                        types[columnOf[key]] = "String";
                    }

                    else types[columnOf[key]] = "Number";

                    curColumn++;
                }
            }

            return new Table(words, types);   
        }
    }
}